package eg.java.net.web.jspx.ui.controls.attrbs;

public @interface JspxAttribute
{

}
