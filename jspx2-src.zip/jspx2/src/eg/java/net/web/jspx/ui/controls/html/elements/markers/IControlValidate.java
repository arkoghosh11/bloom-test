package eg.java.net.web.jspx.ui.controls.html.elements.markers;

/**
 * controls that can validate themselves will implement this interface.
 * 
 * @author amr.eladawy
 * 
 */
public interface IControlValidate extends IValidate
{

}
