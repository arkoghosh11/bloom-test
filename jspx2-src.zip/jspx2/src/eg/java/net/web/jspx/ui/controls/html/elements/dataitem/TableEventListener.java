package eg.java.net.web.jspx.ui.controls.html.elements.dataitem;

public class TableEventListener
{

	public boolean renderDataColumCommand(Object row, DataColumnCommand dataColumnCommand)
	{
		return true;
	}

}
