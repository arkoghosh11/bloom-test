/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.html.elements.dataitem;

import java.util.List;

import org.slf4j.Logger; import org.slf4j.LoggerFactory;

import eg.java.net.web.jspx.engine.data.DAO;
import eg.java.net.web.jspx.engine.error.JspxException;
import eg.java.net.web.jspx.engine.parser.TagFactory;
import eg.java.net.web.jspx.engine.util.SqlUtility;
import eg.java.net.web.jspx.engine.util.StringUtility;
import eg.java.net.web.jspx.ui.controls.attrbs.JspxAttribute;
import eg.java.net.web.jspx.ui.controls.html.elements.hidden.HiddenGenericWebControl;
import eg.java.net.web.jspx.ui.pages.Page;

/**
 * @author Amr.ElAdawy
 *
 */
public class SqlAutoComplete extends HiddenGenericWebControl
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3178121943601626300L;
	private static final Logger logger = LoggerFactory.getLogger(SqlAutoComplete.class);

	/**
	 * @param tagName
	 */
	public SqlAutoComplete()
	{
		super(TagFactory.SqlAutoComplete);
	}

	/**
	 * @param tagName
	 * @param page
	 */
	public SqlAutoComplete(Page page)
	{
		super(TagFactory.SqlAutoComplete, page);
	}

	@JspxAttribute
	protected static String dataSource = "datasource";

	public void setDataSource(String dataSourceVal)
	{
		setAttributeValue(dataSource, dataSourceVal);
	}

	public String getDataSource()
	{
		return getAttributeValue(dataSource);
	}

	@JspxAttribute
	protected String sql = "sql";

	public String getSql()
	{
		return getAttributeValue(sql);
	}

	public void setSql(String sqlValue)
	{
		setAttributeValue(sql, sqlValue);
	}

	@JspxAttribute
	protected String parameter = "parameter";

	public String getParameter()
	{
		return getAttributeValue(parameter);
	}

	public void setParameter(String parameterValue)
	{
		setAttributeValue(parameter, parameterValue);
	}

	@JspxAttribute
	protected String caseSensitiveKey = "casesensitive";

	public boolean getCaseSensitive()
	{
		return getAttributeBooleanValue(caseSensitiveKey);
	}

	public void setCaseSenstive(boolean caseSenstive)
	{
		setAttributeBooleanValue(caseSensitiveKey, caseSenstive);
	}

	/**
	 * gets the list of data based  on the given search key
	 * @return
	 */
	public List<Object> getData(String paramValue)
	{
		String sanitizedParamValue = SqlUtility.encodeForSQL(paramValue);
		logger.debug("ParamValue converted from [" + paramValue + "] to [" + sanitizedParamValue + "]");
		if (StringUtility.isNullOrEmpty(getDataSource()))
			throw new JspxException("The datasource attribute cannot be null in the SqlAutoComplete [" + this.getId() + "]");
		String sql = getSql();
		if (StringUtility.isNullOrEmpty(sql))
			throw new JspxException("The sql attribute cannot be null in the SqlAutoComplete [" + this.getId() + "]");
		String name = getParameter();
		if (StringUtility.isNullOrEmpty(name))
			throw new JspxException("The prameter attribute cannot be null in the SqlAutoComplete [" + this.getId() + "]");

		if (!getCaseSensitive())
		{
			sql = sql.toLowerCase();
			name = name.toLowerCase();
		}
		if (!sql.contains(name))
		{
			logger.error("sql [" + sql + "] does not contain the name [" + name + "]");
			throw new JspxException("DataParam [" + getId() + "] has the Expression [" + sql + "] that does not contain the name [" + name
					+ "] Please make sure of the name exists and match case");
		}
		sql = sql.replace(name, paramValue);
		return DAO.getAutoCompleteList(getDataSource(), sql);
	}
}
