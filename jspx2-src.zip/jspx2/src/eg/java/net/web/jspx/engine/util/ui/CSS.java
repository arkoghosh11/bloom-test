package eg.java.net.web.jspx.engine.util.ui;

public class CSS
{

	private CSS()
	{
	}

	public static final String CSS_CONTROL_GROUP = "control-group";
	public static final String CSS_CONTROL_LABEL = "control-label";
	public static final String CSS_CONTROLS = "controls";
	public static final String CSS_FORM_ACTION = "form-action";
	public static final String CSS_BTN_PRIM = " btn-primary";
	public static final String CSS_BTN_RED = " btn-danger";
	public static final String CSS_BTN_INFO = " btn-info";
	public static final String CSS_FORM_HORIZONTAL = "well form-horizontal";
}
