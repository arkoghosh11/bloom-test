package eg.java.net.web.jspx.ui.controls.html.elements.markers;

public interface IValidator extends IValidate
{
	public String getGroup();
}
