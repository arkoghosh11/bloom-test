/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.html.elements.inputs;

import eg.java.net.web.jspx.engine.RequestHandler;
import eg.java.net.web.jspx.engine.util.StringUtility;
import eg.java.net.web.jspx.engine.util.ui.Render;
import eg.java.net.web.jspx.engine.util.ui.RenderPrinter;
import eg.java.net.web.jspx.ui.controls.attrbs.Attribute;
import eg.java.net.web.jspx.ui.controls.attrbs.JspxAttribute;
import eg.java.net.web.jspx.ui.controls.html.elements.Input;
import eg.java.net.web.jspx.ui.controls.html.elements.Label;
import eg.java.net.web.jspx.ui.pages.Page;

/**
 * @author amr.eladawy
 * 
 */
public class TextBox extends Input
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1451194388571261909L;

	@JspxAttribute
	protected static String onClientChangeKey = "onChange";

	@JspxAttribute
	protected static String onServerChangeKey = "onServerChange";

	@JspxAttribute
	private String readonlyKey = "readonly";
	@JspxAttribute
	private static String inlineKey = "inline";

	public TextBox()
	{
		super();
		setType(Input.TextBox);
	}

	public TextBox(Page page)
	{
		super(page);
		setType(Input.TextBox);
	}

	@Override
	protected void loadInternalAttributes()
	{
		super.loadInternalAttributes();
		internalAttribtes.put(onClientChangeKey.toLowerCase(), 0);
		internalAttribtes.put(onServerChangeKey.toLowerCase(), 0);
		internalAttribtes.put(inlineKey.toLowerCase(), 0);
	}

	@Override
	public void render(RenderPrinter outputStream) throws Exception
	{
		// [Mar 19, 2012 3:00:00 PM] [amr.eladawy] [render inline]
		if (getInline())
		{
			getStyle().put("display", new Attribute("display", "none"));
			Label l = new Label(page);
			if (StringUtility.isNullOrEmpty(getValue()))
				l.setValue(Render.NonBreakSpace + Render.NonBreakSpace + Render.NonBreakSpace);
			else
				l.setValue(getValue());
			l.setCssClass("jspxInline");
			l.setId(getId() + "_label");
			l.render(outputStream);

			String document = "";
			if (page != null && page.isAjaxPostBack && page.isMultiPartForm)
				document = ",window.parent.document";

			String script = new StringBuffer("$('#").append(getId()).append("_label'").append(document)
					.append(").livequery('click',function (){$(this).hide();\n $('#").append(getId())
					.append("').show().focus().attr('value',jQuery.trim($(this).text()));});\n$('#").append(getId()).append("'").append(document)
					.append(").livequery('blur',function (){$(this).hide();\n $('#").append(getId())
					.append("_label').show().html($(this).attr('value')==''?'&nbsp;&nbsp;&nbsp;':$(this).attr('value'));});").toString();
			page.addOnloadScript(script);
		}
		else
		{
			if (RequestHandler.THEME_TWITTER && !noSystemCss)
				setCssClass(getCssClass() + " input-medium");
		}
		super.render(outputStream);
	}

	@Override
	protected void renderAttributes(RenderPrinter outputStream) throws Exception
	{
		String onChangeScript = createServerClientScript(getOnClientChange(), getOnServerChange(), getConfirmation());
		if (!StringUtility.isNullOrEmpty(onChangeScript))
			new Attribute(onClientChangeKey, onChangeScript).render(outputStream, page);
		super.renderAttributes(outputStream);
	}

	public void setReadonly(boolean readonly)
	{
		if (readonly)
			setAttributeValue(readonlyKey, readonlyKey);
		else
			attributes.remove(readonlyKey);
	}

	public boolean isChecked()
	{
		return attributes.contains(readonlyKey);
	}

	private String size = "size";

	public void setSize(int sizeVal)
	{
		setAttributeIntValue(size, sizeVal);
	}

	public int getSize()
	{
		return getAttributeIntValue(size);
	}

	public String getOnClientChange()
	{
		return getAttributeValue(onClientChangeKey);
	}

	public void setOnClientChange(String onClientChange)
	{
		setAttributeValue(onClientChangeKey, onClientChange);
	}

	public String getOnServerChange()
	{
		return getAttributeValue(onServerChangeKey);
	}

	public void setOnServerChange(String onChange)
	{
		setAttributeValue(onServerChangeKey, onChange);
	}

	public boolean getInline()
	{
		return getAttributeBooleanValue(inlineKey);
	}

	public void setInline(boolean inline)
	{
		setAttributeBooleanValue(inlineKey, inline);
	}
}
