/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.html.elements.inputs;

import eg.java.net.web.jspx.ui.controls.html.elements.Input;

/**
 * @author amr.eladawy
 * 
 */
public class Hidden extends Input
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5226601153707892170L;

	public Hidden()
	{
		super();
		setType(Input.HiddenField);
	}
}
