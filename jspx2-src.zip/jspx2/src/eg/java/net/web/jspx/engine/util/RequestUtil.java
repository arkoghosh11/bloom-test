/**
 * 
 */
package eg.java.net.web.jspx.engine.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;

/**
 * Utility for the HTTP request.
 * 
 * @author amr.eladawy
 * 
 */
public class RequestUtil
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(RequestUtil.class);

	private RequestUtil()
	{
	}

	@SuppressWarnings("unchecked")
	public static HashMap<String, FileItem> getParameters(HttpServletRequest request)
	{
		logger.debug("getParameters(request=" + request + ") - start");

		HashMap<String, FileItem> parameters = new HashMap<String, FileItem>();
		List<FileItem> fileItems;
		try
		{
			fileItems = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
			for (Iterator<FileItem> i = fileItems.iterator(); i.hasNext();)
			{
				FileItem fileItem = i.next();
				parameters.put(fileItem.getFieldName(), fileItem);
			}
		}
		catch (FileUploadException e)
		{
			logger.error("getParameters()", e);
		}
		return parameters;
	}
}
