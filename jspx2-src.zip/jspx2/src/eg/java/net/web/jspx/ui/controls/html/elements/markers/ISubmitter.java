/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.html.elements.markers;

/**
 * Marker Interface for the Controls that can submit data i.e. Form.
 * later on Update Panel in Ajax will be using it.
 * @author amr.eladawy
 *
 */
public interface ISubmitter
{

}
