package eg.java.net.web.jspx.ui.controls.html.elements.dataitem;

import java.util.ArrayList;
import java.util.List;

import eg.java.net.web.jspx.engine.parser.TagFactory;
import eg.java.net.web.jspx.engine.util.ELUtility;
import eg.java.net.web.jspx.engine.util.StringUtility;
import eg.java.net.web.jspx.engine.util.bean.RepeaterUtility;
import eg.java.net.web.jspx.engine.util.ui.RenderPrinter;
import eg.java.net.web.jspx.ui.controls.WebControl;
import eg.java.net.web.jspx.ui.controls.attrbs.JspxAttribute;
import eg.java.net.web.jspx.ui.controls.html.elements.hidden.HiddenGenericWebControl;
import eg.java.net.web.jspx.ui.pages.Page;

public class Repeater extends HiddenGenericWebControl
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5282832537487303409L;

	public Repeater()
	{
		super(TagFactory.Repeater);
	}

	public Repeater(String tagName)
	{
		super(tagName);
	}

	public Repeater(String tagName, Page page)
	{
		super(tagName, page);
	}

	@Override
	public void render(RenderPrinter outputStream) throws Exception
	{
		String oName = getObjectName();
		bind();
		int i = 0;
		for (Object object : list)
		{
			changeIds(i);
			if (!StringUtility.isNullOrEmpty(oName))
			{
				page.request.setAttribute(Page.RepeaterNamePrefix + oName, object);
				// [Jul 16, 2013 1:08:45 PM] [Amr.ElAdawy] [adding the repeater object to the jexl context]
				RepeaterUtility.addRepeaterObjectToJexlMap(page, oName, object);
			}
			renderChildren(outputStream);
			i++;
		}
	}

	private void changeIds(int counter)
	{
		String changId = getAttributeValue(changeId);
		boolean change = StringUtility.isNullOrEmpty(changId) || changId.equalsIgnoreCase("true");
		if (change)
			setControlId(this, counter);
	}

	private void setControlId(WebControl startControl, int counter)
	{
		for (WebControl control : startControl.getControls())
		{
			if (!StringUtility.isNullOrEmpty(control.getId()))
			{
				String changId = control.getAttributeValue(changeId);
				boolean change = StringUtility.isNullOrEmpty(changId) || changId.equalsIgnoreCase("true");
				if (change)
				{
					String id = control.getId();
					if (counter == 0)
					{
						control.setAttributeValue("original_id", id);
					}
					else
					{
						id = control.getAttributeValue("original_id");
					}
					control.setId(id + "" + counter);
				}
			}
			setControlId(control, counter);
		}
	}

	@SuppressWarnings("unchecked")
	public void bind()
	{
		String itemListName = getItemList();
		if (!StringUtility.isNullOrEmpty(itemListName))
			list = (List<Object>) ELUtility.evaluateEL("${this." + itemListName + "}", page);
		else
			list = (List<Object>) getAttributeValueObject(listKey);
		if (list == null)
			list = new ArrayList<Object>();

		// list = (List<Object>) PropertyAccessor.getProperty(page, itemListName);
		// if (list == null)
		// {
		// // try to get it from the request as a repeater object
		// String objName = itemListName;
		// if (objName.indexOf(".") > 0)
		// {
		// objName = itemListName.substring(0, itemListName.indexOf("."));
		// }
		// Object repObject = page.request.getAttribute(Page.RepeaterNamePrefix + objName);
		// if (repObject != null && itemListName.indexOf(".") > 0)
		// {
		// objName = itemListName.substring(itemListName.indexOf(".") + 1);
		// repObject = PropertyAccessor.getProperty(repObject, objName);
		// }
		// if (repObject != null)
		// list = (List<Object>) repObject;
		// else
		// list = new ArrayList<Object>();
		// }
	}

	List<Object> list = new ArrayList<Object>();

	@JspxAttribute
	protected String changeId = "changeid";

	public void setChangeId(String ChangeId)
	{
		setAttributeValue(changeId, ChangeId);
	}

	public String getChangeId()
	{
		return getAttributeValue(changeId);
	}

	@JspxAttribute
	protected String objectName = "var";

	public void setObjectName(String ObjectName)
	{
		setAttributeValue(objectName, ObjectName);
	}

	public String getObjectName()
	{
		return getAttributeValue(objectName);
	}

	@JspxAttribute
	protected String itemList = "itemlist";

	public void setItemList(String itemListName)
	{
		setAttributeValue(itemList, itemListName);
	}

	public String getItemList()
	{
		return getAttributeValue(itemList);
	}

	@JspxAttribute
	protected static String listKey = "list";

	public void setList(String listVal)
	{
		setAttributeValue(listKey, listVal);
	}

	public String getList()
	{
		return getAttributeValue(listKey);
	}
}
