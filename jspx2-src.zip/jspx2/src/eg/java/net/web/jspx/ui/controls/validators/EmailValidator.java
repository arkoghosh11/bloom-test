/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.validators;

import java.util.regex.Pattern;

import eg.java.net.web.jspx.engine.util.StringUtility;
import eg.java.net.web.jspx.ui.controls.html.elements.Input;
import eg.java.net.web.jspx.ui.controls.html.elements.markers.ValueHolder;

/**
 * @author amr.eladawy
 * 
 */
public class EmailValidator extends Validator
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2759429395017936306L;

	/**
	 * @param validationType
	 */
	public EmailValidator()
	{
		super("2");
		//		expersion = "/^((([a-z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+(\\.([a-z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(\\\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.)+(([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.?$/i";
		expersion = "[\\w-]+@([\\w-]+\\.)+[\\w-]+";
		//		expersion = "^[a-zA-Z]([.]?([[:alnum:]_-]+)*)?@([[:alnum:]\\-_]+\\.)+[a-zA-Z]{2,4}$ ";
		//		expersion = "\\b[A-Z0-9._%+-]+@(?:[A-Z0-9-]+\\.)+[A-Z]{2,4}\\b";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see eg.java.net.web.jspx.ui.controls.validators.Validator#validate()
	 */
	@Override
	public void validate() throws ValidationException
	{
		getControlToValidate();
		String s = ((ValueHolder) controlToValidate).getValue();
		if (StringUtility.isNullOrEmpty(s))
			return;
		String data = s;
		if (controlToValidate instanceof Input && !Pattern.compile(expersion).matcher(data).find())
		{
			invalid = true;
			throw new ValidationException("Invalid Email Address [" + data + "]");
		}
	}

}
