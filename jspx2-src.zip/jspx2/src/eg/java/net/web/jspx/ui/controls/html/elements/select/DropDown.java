package eg.java.net.web.jspx.ui.controls.html.elements.select;

/**
 * a select with a size 1
 * 
 * @author amr.eladawy
 * 
 */
public class DropDown extends Select
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6854219352266646371L;
}
