package eg.java.net.web.jspx.ui.controls.html.elements.select;

/**
 * a select with Size >1
 * @author amr.eladawy
 *
 */
public class List extends Select
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2676305517863901267L;

}
