/**
 * 
 */
package eg.java.net.web.jspx.engine.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eg.java.net.web.jspx.engine.RequestHandler;
import eg.java.net.web.jspx.engine.error.JspxException;
import eg.java.net.web.jspx.engine.util.StringUtility;

/**
 * @author amr.eladawy
 * 
 */
public class DAO
{
	private static final Logger logger = LoggerFactory.getLogger(DAO.class);

	public static List<Hashtable<String, DataField>> search(String datasource, String sql, int start, int size, boolean getTotalCount,
			List<Integer> totalCount) throws Exception
	{
		if (StringUtility.isNullOrEmpty(datasource))
			throw new JspxException("Data Source cannot be empty");
		List<Hashtable<String, DataField>> rows = new ArrayList<Hashtable<String, DataField>>();
		Hashtable<String, DataField> cols = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			DataSource ds = ((DataSource) new InitialContext().lookup(datasource));
			if (ds == null)
				throw new JspxException("Cannot lookup Data Source [" + datasource + "]");
			connection = ds.getConnection();
			statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			if (RequestHandler.SHOW_SQL)
				logger.info("search() - sql=" + sql);
			// [Aug 19, 2012 6:54:14 PM] [Amr.ElAdawy] [remove 1=1]
			sql = sql.replace("AND 1=1", "");
			sql = sql.replaceAll("AND[ ]*1=1", "");
			sql = sql.replace("and 1=1", "");

			if (RequestHandler.SHOW_SQL)
				logger.info("search() -executed  sql=" + sql);
			resultSet = statement.executeQuery(sql);
			int counter = 0;
			String fieldName;
			String fieldOriginalName;
			String fieldType;
			if (resultSet.absolute(start + 1))
			{
				int colCount = resultSet.getMetaData().getColumnCount();
				do
				{
					cols = new Hashtable<String, DataField>();
					for (int i = 1; i <= colCount; i++)
					{
						fieldOriginalName = resultSet.getMetaData().getColumnLabel(i).trim();
						fieldName = fieldOriginalName.toLowerCase();
						fieldType = resultSet.getMetaData().getColumnTypeName(i).trim();
						if (fieldType.equals("TIMESTAMP"))
							cols.put(fieldName, new DataField(fieldName, resultSet.getTimestamp(i), fieldType, i, fieldOriginalName));
						else
							cols.put(fieldName, new DataField(fieldName, resultSet.getObject(i), fieldType, i, fieldOriginalName));
					}
					rows.add(cols);
				}
				while (resultSet.next() && (++counter < size));
			}
			// [Jul 17, 2011 7:07:21 PM] [amr.eladawy] [getting the count of the rows along with the results.]
			if (getTotalCount)
			{
				// resultSet.last();
				// totalCount.add(resultSet.getRow());
				totalCount.add(totalCount(connection, sql));
			}
			else if (totalCount != null)
				totalCount.add(Integer.MAX_VALUE);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
		return rows;
	}

	public static int totalCount(Connection connection, String sql) throws Exception
	{
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select count(1) from (" + sql + ") totalResult");
			if (resultSet.next())
				return resultSet.getInt(1);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
		}
		return 0;
	}

	public static int totalCount(String datasource, String sql) throws Exception
	{
		Connection connection = null;
		try
		{
			connection = ((DataSource) new InitialContext().lookup(datasource)).getConnection();
			return totalCount(connection, sql);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
	}

	public static int executeNoneQuery(String datasource, String sql) throws Exception
	{
		Connection connection = null;
		Statement statement = null;
		try
		{
			connection = ((DataSource) new InitialContext().lookup(datasource)).getConnection();
			statement = connection.createStatement();
			logger.debug("executeNoneQuery() - sql=" + sql);
			return statement.executeUpdate(sql);
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
	}

	/**
	 * loads the lookup control from the DB. returns hashmap of the key-value pairs. and also loads the keys List with keys data.
	 * 
	 * @param datasource
	 * @param sql
	 * @param keys
	 * @return
	 */
	public static Hashtable<String, String> loadLookup(String datasource, String sql, List<String> keys)
	{
		Hashtable<String, String> hashtable = new Hashtable<String, String>();
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			connection = ((DataSource) new InitialContext().lookup(datasource)).getConnection();
			statement = connection.createStatement();
			if (RequestHandler.SHOW_SQL)
				logger.info("loadLookup() - sql=" + sql);
			resultSet = statement.executeQuery(sql);
			while (resultSet.next())
			{
				hashtable.put(resultSet.getString(1), resultSet.getString(2));
				keys.add(resultSet.getString(1));
			}
		}
		catch (Exception e)
		{
			logger.error("Failed to load lookup", e);
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
		return hashtable;
	}

	/**
	 * looks up for a certain field based on the given sql
	 * 
	 * @param datasource
	 *            the data source
	 * @param sql
	 *            the statement to be executed
	 * @param defaultObject
	 *            the default value to be returned
	 * @param keyField
	 *            the name of the field to be looked up
	 * @return
	 */
	public static Object lookup(String datasource, String sql, Object defaultObject, String keyField)
	{
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			connection = ((DataSource) new InitialContext().lookup(datasource)).getConnection();
			statement = connection.createStatement();
			if (RequestHandler.SHOW_SQL)
				logger.info("lookup() - sql=" + sql);
			resultSet = statement.executeQuery(sql);
			if (resultSet.next())
				return resultSet.getObject(keyField);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
		return defaultObject;
	}

	public static long getSeqNextVal(String datasource, String seqName)
	{
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			connection = ((DataSource) new InitialContext().lookup(datasource)).getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT ".concat(seqName).concat(".NEXTVAL FROM DUAL"));
			if (resultSet.next())
				return resultSet.getLong(1);
		}
		catch (Exception e)
		{
			logger.error("Failed to get sequence value", e);
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
		return 0;
	}

	/**
	 * gets list of objects out of sql statement.
	 * 
	 * @param datasource
	 * @param sql
	 * @return
	 */
	public static List<Object> getAutoCompleteList(String datasource, String sql)
	{
		List<Object> res = new ArrayList<Object>();
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			connection = ((DataSource) new InitialContext().lookup(datasource)).getConnection();
			statement = connection.createStatement();
			logger.debug("getting auto complete sql :" + sql);
			resultSet = statement.executeQuery(sql);
			while (resultSet.next())
				res.add(resultSet.getObject(1));
		}
		catch (Exception e)
		{
			logger.error("Failed to execute Auto Complete SQL", e);
		}
		finally
		{
			try
			{
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
			}
			try
			{
				if (connection != null)
					connection.close();
			}
			catch (SQLException e)
			{
			}
		}
		return res;
	}
}
