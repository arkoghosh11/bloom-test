package eg.java.net.web.jspx.ui.controls.html.elements.markers;

public interface ItemDataBound
{
	public void dataBind();

	public void reverseBinding();
}
