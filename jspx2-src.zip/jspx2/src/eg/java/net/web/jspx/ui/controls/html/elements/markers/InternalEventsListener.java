package eg.java.net.web.jspx.ui.controls.html.elements.markers;

public interface InternalEventsListener
{

	void setInteralPostback(boolean isInternalPostback);
}
