/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.html.w3;

import eg.java.net.web.jspx.engine.parser.TagFactory;
import eg.java.net.web.jspx.engine.util.ui.RenderPrinter;
import eg.java.net.web.jspx.ui.controls.html.GenericWebControl;
import eg.java.net.web.jspx.ui.pages.Page;

/**
 * @author amr.eladawy
 * 
 */
public class Body extends GenericWebControl
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5749671135622186812L;

	public Body()
	{
		super(TagFactory.Body);
	}

	public Body(Page page)
	{
		super(TagFactory.Body, page);
	}

	@Override
	protected void preRenderEndTag(RenderPrinter outputStream) throws Exception
	{
		page.renderOnloadScripts(outputStream);
	}
}
