/**
 * 
 */
package eg.java.net.web.jspx.ui.controls.html.elements.inputs;

import eg.java.net.web.jspx.ui.controls.html.elements.Input;

/**
 * @author amr.eladawy
 * 
 */
public class ResetButton extends Input
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4529441959511423322L;

	public ResetButton()
	{
		super();
		setType(Reset);
	}

}
